﻿using System.ComponentModel;
using System.Data;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;
using static System.Console;
using CsvHelper.Configuration;
using System.Net;
using System.Reflection;

namespace Ydictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("dictionary is from https://github.com/skywind3000/ECDICT");
            Method z = new Method();
            using (var stream = z.GetEmbeddedCsvStream())
            {
                Console.WriteLine(stream);
                
                
                using (var reader = new StreamReader(stream))
                {

                    using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                    {
                        z.SearchWorker(z, reader, csv);
                    }
                }

                
            }

        }

        
    }

    class Method
    {
        public string Normalize(String _Input)
        {
            if (_Input == "")
                return _Input;
            return _Input.Replace("`", "'").Replace("‘", "'").Replace("’", "'").Trim();
        }
        public bool NeedExit(string? search)
        {
            if (string.Equals("quit", search, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
            return false;
        }
        public Stream GetEmbeddedCsvStream()
        {
            var assembly= Assembly.GetExecutingAssembly();
            var resourceStream = assembly.GetManifestResourceStream("CMD_Translator.ecdict.csv");
            

            return resourceStream;
        }
        public void No()
        {
            WriteLine("not found");
        }
        public void Enter()
        {
            WriteLine("\n");
        }
        public void Line()
        {
            WriteLine("____________________________");
        }
        public void SearchWorker(Method z, StreamReader reader, CsvReader csv)
        {
            while (true)
            {

                z.Line();
                
                z.Enter();

                WriteLine("input word or enter \"quit \" to exit:  ");
                
                string? search = ReadLine();
                search = z.Normalize(search);
                bool found = false;
                if (z.NeedExit(search)) break;
                WriteLine("wait  for searching  `" + search + "`...");
                var records = csv.GetRecords<Word>();
                foreach (var record in records)
                {
                    if (string.Equals(record.word, search, StringComparison.OrdinalIgnoreCase))
                    {
                        WriteLine(record.translation);
                        found = true; break;
                    }
                }

                if (!found) z.No();
                reader.BaseStream.Seek(0, SeekOrigin.Begin); // 重置流
                reader.DiscardBufferedData();
            }
        }
    }

    class Word
    {
        public string? word { get; set; }
        public string? phonetic { get; set; }
        public string? definition { get; set; }
        public string? translation { get; set; }
        public string? pos { get; set; }
        public string? collins { get; set; }
        public string? oxford { get; set; }
        public string? tag { get; set; }
        public string? bnc { get; set; }
        public string? frq { get; set; }
        public string? exchange { get; set; }
        public string? detail { get; set; }
        public string? audio { get; set; }
    }

    





}
